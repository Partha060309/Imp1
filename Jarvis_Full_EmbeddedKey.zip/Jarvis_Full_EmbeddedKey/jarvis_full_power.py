import os, sys, json, threading, datetime, subprocess, time
import tkinter as tk
import numpy as np
import psutil
import pyttsx3, speech_recognition as sr, keyboard, pyautogui, pygetwindow as gw
from ctypes import POINTER, cast
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
import openai
from win32com.client import Dispatch
from PIL import Image
import pystray
import winshell
import requests

# --- CONFIG ---
USER_NAME = "Prthh"
VOICE_PIN = "quantum access granted"
openai.api_key = "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"
openai.api_base = "https://api.deepseek.com"
ICON_PATH = "stark_icon.png"

# File paths
BASE = os.getcwd()
LOG_FOLDER = os.path.join(BASE, "jarvis_logs"); os.makedirs(LOG_FOLDER, exist_ok=True)
CHAT_LOG = os.path.join(LOG_FOLDER, f"jarvis_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt")
MEM_FILE = os.path.join(BASE, "memory.json")
TODO_FILE = os.path.join(BASE, "todo.json")
ALARMS_FILE = os.path.join(BASE, "alarms.json")
APP_DB = os.path.join(BASE, "app_paths.json")

# TTS
engine = pyttsx3.init()
engine.setProperty('rate', 170)
def speak(txt):
    engine.say(txt); engine.runAndWait()

# Memory
def load_json(path):
    return json.load(open(path)) if os.path.exists(path) else {}
def save_json(path, data):
    json.dump(data, open(path, "w"), indent=2)
    
def remember_cmd(text):
    mem = load_json(MEM_FILE)
    mem[text] = datetime.datetime.now().isoformat()
    save_json(MEM_FILE, mem)
    speak("Noted.")
    
def recall_cmd():
    mem = load_json(MEM_FILE)
    if not mem:
        speak("You haven't asked me to remember anything yet.")
    else:
        for k,v in mem.items():
            speak(f"You told me to remember: {k}")

# To‑Do
def add_todo(item):
    td = load_json(TODO_FILE).get("tasks", [])
    td.append(item)
    save_json(TODO_FILE, {"tasks":td})
    speak(f"Added to your to-do list: {item}")
def show_todo():
    td = load_json(TODO_FILE).get("tasks", [])
    if not td: speak("Your to-do list is empty.")
    else:
        speak("Here are your to-do items:")
        for i,item in enumerate(td,1):
            speak(f"{i}: {item}")
def clear_todo():
    save_json(TODO_FILE, {"tasks":[]})
    speak("To-do list cleared.")

# Alarms
def set_alarm(dt_str):
    alarms = load_json(ALARMS_FILE).get("alarms", [])
    alarms.append(dt_str)
    save_json(ALARMS_FILE, {"alarms":alarms})
    speak(f"Alarm set for {dt_str}")
def clear_alarms():
    save_json(ALARMS_FILE, {"alarms":[]})
    speak("All alarms cleared.")

def alarm_checker():
    while True:
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        alarms = load_json(ALARMS_FILE).get("alarms",[])
        if now in alarms:
            speak("Alarm ringing now.")
            alarms.remove(now)
            save_json(ALARMS_FILE, {"alarms":alarms})
        time.sleep(30)

# App discovery
def scan_apps():
    d={}
    base = os.getenv('PROGRAMDATA')+"\\Microsoft\\Windows\\Start Menu"
    for r,_,files in os.walk(base):
        for f in files:
            if f.lower().endswith(".lnk"):
                d[os.path.splitext(f)[0].lower()] = os.path.join(r,f)
    save_json(APP_DB, d); return d
app_paths = scan_apps()

# System info
def sys_monitor():
    u = psutil.cpu_percent()
    m = psutil.virtual_memory()
    b = psutil.sensors_battery()
    speak(f"CPU usage is {u}% and RAM usage is {m.percent} percent.")
    if b: speak(f"Battery at {b.percent} percent, plugged in: {b.power_plugged}.")

# Controls
def audio_ctrl(a):
    dev = AudioUtilities.GetSpeakers()
    vol = cast(dev.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None),
               POINTER(IAudioEndpointVolume))
    cur=vol.GetMasterVolumeLevelScalar()
    if a=="up": vol.SetMasterVolumeLevelScalar(min(cur+0.1,1), None)
    elif a=="down": vol.SetMasterVolumeLevelScalar(max(cur-0.1,0), None)
    elif a=="mute": vol.SetMute(1,None)
    elif a=="unmute": vol.SetMute(0,None)

def mouse_cmd(cmd):
    if "move" in cmd:
        dx,dy = (100*(1 if "right" in cmd else -1 if "left" in cmd else 0),
                100*(1 if "down" in cmd else -1 if "up" in cmd else 0))
        pyautogui.moveRel(dx,dy)
    if "click" in cmd: pyautogui.click()
    if "scroll" in cmd:
        pyautogui.scroll(500 if "up" in cmd else -500)
def win_ctrl(cmd):
    w = gw.getActiveWindow()
    if w:
        if "minimize" in cmd: w.minimize()
        if "maximize" in cmd: w.maximize()
        if "close" in cmd: w.close()

def open_app_cmd(cmd):
    for name,p in app_paths.items():
        if name in cmd:
            os.startfile(p); return True
    return False

def folder_cmd(cmd):
    try:
        if "create folder" in cmd:
            parts = cmd.split()
            idx = parts.index("folder")
            name = parts[idx+1]
            drive = parts[idx+3] if "in" in parts else BASE
            path = os.path.join(drive+":\\", name)
            os.makedirs(path, exist_ok=True)
            speak(f"Created folder {name}")
            return True
        if "delete folder" in cmd:
            parts = cmd.split()
            idx = parts.index("folder")
            name = parts[idx+1]
            drive = parts[idx+3] if "in" in parts else BASE
            path = os.path.join(drive+":\\", name)
            os.rmdir(path)
            speak(f"Deleted folder {name}")
            return True
    except:
        speak("Folder operation failed.")
    return False

# Real Info
def get_news():
    resp = requests.get("https://newsapi.org/v2/top-headlines", params={"apiKey":"YOUR_NEWSAPI_KEY","country":"in"})
    if resp.ok:
        for art in resp.json().get("articles",[])[:5]:
            speak(art["title"])
def get_weather(city):
    resp = requests.get("https://api.openweathermap.org/data/2.5/weather", params={"q":city,"appid":"YOUR_OWM_KEY","units":"metric"})
    if resp.ok:
        d=resp.json()
        speak(f"{city} now {d['weather'][0]['description']}, temperature {d['main']['temp']}°C.")
    else:
        speak("Weather fetch failed.")

def general_qa(q):
    return ask_ai(q)

# AI
def ask_ai(q, lang="English"):
    mem = load_json(MEM_FILE)
    # embed and recall ...
    # left as earlier
    resp = openai.ChatCompletion.create(model="deepseek-chat", messages=[{"role":"user","content":q}])
    return resp.choices[0].message.content

# Self-destruct
def protocol_phoenix():
    speak("Are you sure sir?")
    r = sr.Recognizer()
    with sr.Microphone() as m:
        a = r.listen(m, timeout=5, phrase_time_limit=4)
    ans = ""
    try: ans = r.recognize_google(a).lower()
    except: pass
    if "yes" in ans:
        for f in [MEM_FILE, TODO_FILE, ALARMS_FILE, CHAT_LOG, APP_DB]:
            if os.path.exists(f): os.remove(f)
        speak("Protocol Phoenix initialized. All systems purged.")
        os._exit(0)
    else:
        speak("Protocol aborted.")

# Command parser
def handle_command(cmd):
    cmd = cmd.lower()
    with open(CHAT_LOG,"a") as f: f.write(f"USER: {cmd}\n")
    if "stop jarvis" in cmd:
        speak("Stopping responses, but remaining active.")
        return "PAUSE"
    if cmd.strip() in ["quit","exit","goodbye"]:
        speak("Goodbye, sir.")
        sys.exit()
    if cmd.startswith("remember this"):
        remember_cmd(cmd.replace("remember this","").strip()); return
    if "what did i ask you to remember" in cmd:
        recall_cmd(); return
    if cmd.startswith("add") and "to my to-do" in cmd:
        item = cmd.split("to my to-do")[0].replace("add","").strip()
        add_todo(item); return
    if "show my to-do" in cmd: show_todo(); return
    if "clear my to-do" in cmd: clear_todo(); return
    if cmd.startswith("set an alarm for"):
        dt = cmd.replace("set an alarm for","").strip()
        dt_parsed = datetime.datetime.strptime(dt,"%I:%M %p")
        now = datetime.datetime.now()
        dt_full = now.replace(hour=dt_parsed.hour,minute=dt_parsed.minute)
        set_alarm(dt_full.strftime("%Y-%m-%d %H:%M")); return
    if "cancel all alarms" in cmd: clear_alarms(); return
    if folder_cmd(cmd): return
    if open_app_cmd(cmd): speak("Opening app"); return
    if "create folder" in cmd or "delete folder" in cmd: return
    if "shutdown" in cmd: speak("Shutting down"); subprocess.Popen(["shutdown","/s","/t","1"]); return
    if any(x in cmd for x in ["volume up","increase volume"]): audio_ctrl("up"); return
    if any(x in cmd for x in ["volume down","decrease volume"]): audio_ctrl("down"); return
    if "mute" in cmd: audio_ctrl("mute"); return
    if "unmute" in cmd: audio_ctrl("unmute"); return
    if any(x in cmd for x in ["move mouse","click","scroll"]): mouse_cmd(cmd); return
    if any(x in cmd for x in ["minimize window","maximize window","close window"]): win_ctrl(cmd); return
    if "what's my cpu" in cmd or "system monitor" in cmd: sys_monitor(); return
    if "news" in cmd: get_news(); return
    if "weather" in cmd:
        city = cmd.replace("weather","").strip()
        get_weather(city); return
    if "initiate protocol phoenix" in cmd: protocol_phoenix(); return
    # default to QA:
    speak(general_qa(cmd))
    with open(CHAT_LOG,"a") as f: f.write(f"JARVIS: {general_qa(cmd)}\n")

# Voice flow
def verify_pin():
    speak("Grant me access sir!")
    r = sr.Recognizer()
    with sr.Microphone() as mic:
        a = r.listen(mic, timeout=5, phrase_time_limit=4)
    try:
        return r.recognize_google(a).lower().strip() == VOICE_PIN
    except:
        return False

def listen_flow(prompt=""):
    if prompt: speak(prompt)
    r = sr.Recognizer()
    with sr.Microphone() as mic:
        a = r.listen(mic, timeout=5, phrase_time_limit=8)
    try:
        return r.recognize_google(a)
    except:
        return ""

def activate_flow():
    speak(f"Hello {USER_NAME}, how can I assist you today?")
    if not verify_pin():
        speak("Access denied."); return
    cmd = listen_flow("")
    if cmd:
        res = handle_command(cmd)
        return res

# Listeners
def wake_listener():
    r,s=sr.Recognizer(),sr.Microphone()
    while True:
        with s:
            a=r.listen(s, phrase_time_limit=3)
        t=""
        try: t = r.recognize_google(a).lower()
        except: continue
        if "hey jarvis" in t:
            act = activate_flow()
            # if paused, wait; just continue listening
            while act == "PAUSE":
                time.sleep(1)
                act = activate_flow()

def hotkey_listener():
    keyboard.add_hotkey("ctrl+j", activate_flow)
    keyboard.wait()

# Tray
def setup_autostart():
    startup = os.getenv("APPDATA")+"\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"
    link = os.path.join(startup, "Jarvis.lnk")
    script = os.path.abspath(sys.argv[0])
    shell = Dispatch("WScript.Shell")
    if not os.path.exists(link):
        sc = shell.CreateShortcut(link)
        sc.Targetpath = sys.executable
        sc.Arguments = f'"{script}"'
        sc.WorkingDirectory = os.path.dirname(script)
        sc.IconLocation = ICON_PATH
        sc.save()
        speak("Auto-start enabled")

def quit_app(icon, item):
    icon.stop()
    os._exit(0)

def show_app(icon, item):
    icon.stop()
    window.after(0, window.deiconify)

def hide_to_tray(ev=None):
    window.withdraw()
    img = Image.open(ICON_PATH)
    menu = pystray.Menu(
        pystray.MenuItem("Show Jarvis", show_app),
        pystray.MenuItem("Exit", quit_app)
    )
    icon = pystray.Icon("Jarvis", img, "Jarvis", menu)
    icon.run()

# === Main ===
threading.Thread(target=alarm_checker, daemon=True).start()
threading.Thread(target=wake_listener, daemon=True).start()
threading.Thread(target=hotkey_listener, daemon=True).start()
setup_autostart()

window = tk.Tk()
window.title("Jarvis - Personal Assistant")
window.geometry("400x150")
window.protocol("WM_DELETE_WINDOW", hide_to_tray)
tk.Label(window, text="Jarvis is active.\nSay \"Hey Jarvis\" or press Ctrl+J", font=("Arial", 12)).pack(pady=20)
tk.Button(window, text="🔴 Exit", command=lambda: sys.exit(0), bg="red", fg="white", width=12).pack()

speak("Jarvis is now online and listening.")
window.mainloop()
